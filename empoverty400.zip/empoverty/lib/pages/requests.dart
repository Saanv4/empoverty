class requestsData {
  String fieldofWork;
  String workerLocation;
  String workerName;
  String workerPhoneNumber;
  String timeofService;
  String userName;
  String userLocation;
  String userphoneNumber;



  requestsData({
    required this.fieldofWork,
    required this.workerLocation,
    required this.workerName,
    required this.workerPhoneNumber,
    required this.timeofService,
    required this.userName,
    required this.userLocation,
    required this.userphoneNumber,


  });
}
