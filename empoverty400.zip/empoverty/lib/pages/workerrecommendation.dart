class Recommendations {
  String ShopOwnerName;
  String ShopOwnerPhoneNumber;
  String ShopCategory;
  String workerName;
  String workerField;
  String workerPhoneNumber;

  Recommendations({
    required this.ShopOwnerName,
    required this.ShopOwnerPhoneNumber,
    required this.ShopCategory,
    required this.workerName,
    required this.workerField,
    required this.workerPhoneNumber,
  });
}
