package com.example.empoverty

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
