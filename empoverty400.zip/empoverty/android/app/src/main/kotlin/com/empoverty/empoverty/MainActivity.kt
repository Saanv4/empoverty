package com.empoverty.empoverty

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
